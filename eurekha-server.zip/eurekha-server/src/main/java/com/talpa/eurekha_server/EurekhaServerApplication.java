package com.talpa.eurekha_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekhaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekhaServerApplication.class, args);
	}

}
